"use client"

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Menu, X } from 'lucide-react'

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollTo = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
    setIsMenuOpen(false)
  }

  return (
    <motion.header 
      className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white bg-opacity-90 dark:bg-gray-800 dark:bg-opacity-90 backdrop-blur-sm shadow-md' : 'bg-transparent'}`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <motion.div
          className="text-2xl font-bold text-primary cursor-pointer"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => scrollTo('hero')}
        >
          OTP2Link
        </motion.div>
        <nav className="hidden md:flex space-x-4">
          {['features', 'how-it-works', 'pricing', 'contact'].map((item) => (
            <motion.button
              key={item}
              className="text-gray-600 hover:text-primary dark:text-gray-300 dark:hover:text-primary"
              onClick={() => scrollTo(item)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {item.charAt(0).toUpperCase() + item.slice(1).replace('-', ' ')}
            </motion.button>
          ))}
        </nav>
        <div className="hidden md:block">
          <Button onClick={() => scrollTo('contact')}>Get Started</Button>
        </div>
        <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X className="h-6 w-6 text-gray-600 dark:text-gray-300" /> : <Menu className="h-6 w-6 text-gray-600 dark:text-gray-300" />}
        </button>
      </div>
      {isMenuOpen && (
        <motion.div 
          className="md:hidden bg-white dark:bg-gray-800 py-2"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          <nav className="flex flex-col space-y-2 px-4">
            {['features', 'how-it-works', 'pricing', 'contact'].map((item) => (
              <motion.button
                key={item}
                className="text-gray-600 hover:text-primary dark:text-gray-300 dark:hover:text-primary text-left py-2"
                onClick={() => scrollTo(item)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {item.charAt(0).toUpperCase() + item.slice(1).replace('-', ' ')}
              </motion.button>
            ))}
            <Button className="w-full" onClick={() => scrollTo('contact')}>Get Started</Button>
          </nav>
        </motion.div>
      )}
    </motion.header>
  )
}

export default Header

