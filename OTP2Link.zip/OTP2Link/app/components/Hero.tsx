"use client"

import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { OrbitControls, PerspectiveCamera, Text, RoundedBox } from '@react-three/drei'
import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Suspense, useRef } from 'react'
import * as THREE from 'three'

function useResponsivePhone() {
  const { viewport } = useThree()
  const scale = Math.min(1, viewport.width / 8)
  return { scale }
}

function FloatingParticle({ position }: { position: [number, number, number] }) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2 + position[0]) * 0.2
    }
  })

  return (
    <mesh ref={meshRef} position={position}>
      <sphereGeometry args={[0.05, 16, 16]} />
      <meshBasicMaterial color="#4a90e2" />
    </mesh>
  )
}

function IPhone() {
  const phoneRef = useRef<THREE.Group>(null)
  const { scale } = useResponsivePhone()

  useFrame((state) => {
    if (phoneRef.current) {
      phoneRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 2) * 0.2
      phoneRef.current.position.y = Math.sin(state.clock.elapsedTime * 3) * 0.1 * scale
    }
  })

  return (
    <group ref={phoneRef} scale={[scale, scale, scale]}>
      {/* Phone frame */}
      <RoundedBox args={[2.8, 5.5, 0.4]} radius={0.1} smoothness={4}>
        <meshPhongMaterial color="#1c1c1c" />
      </RoundedBox>

      {/* Screen background */}
      <mesh position={[0, 0, 0.201]}>
        <planeGeometry args={[2.6, 5.3]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>

      {/* OTP Screen Content */}
      <group position={[0, 0, 0.202]}>
        {/* Title */}
        <Text 
          position={[0, 1.8, 0]} 
          fontSize={0.35}
          color="#000000"
          font="/fonts/Inter-Bold.ttf"
          textAlign="center"
          anchorY="middle"
        >
          Enter OTP
        </Text>

        {/* OTP Input Boxes */}
        {[-0.9, -0.3, 0.3, 0.9].map((x, i) => (
          <group key={i} position={[x, 0.8, 0]}>
            <RoundedBox args={[0.4, 0.6, 0.05]} radius={0.05} smoothness={4}>
              <meshBasicMaterial color="#e6f2ff" />
            </RoundedBox>
            <mesh position={[0, -0.35, 0.03]}>
              <planeGeometry args={[0.4, 0.02]} />
              <meshBasicMaterial color="#1e90ff" />
            </mesh>
          </group>
        ))}

        {/* Resend Link */}
        <Text 
          position={[0, 0, 0]} 
          fontSize={0.25}
          color="#1e90ff"
          font="/fonts/Inter-Regular.ttf"
          textAlign="center"
          anchorY="middle"
        >
          Resend OTP
        </Text>

        {/* Verify Button */}
        <group position={[0, -0.8, 0]}>
          <RoundedBox args={[2, 0.6, 0.1]} radius={0.1} smoothness={4}>
            <meshBasicMaterial color="#1e90ff" />
          </RoundedBox>
          <Text 
            position={[0, 0, 0.06]} 
            fontSize={0.25}
            color="#ffffff"
            font="/fonts/Inter-Bold.ttf"
            textAlign="center"
            anchorY="middle"
          >
            Verify
          </Text>
        </group>
      </group>
    </group>
  )
}

function Scene() {
  return (
    <>
      <IPhone />
      {[[-2, 0, 0], [2, 0, 0], [0, 2, 0], [0, -2, 0], [-1.5, 1.5, 0], [1.5, -1.5, 0]].map((position, index) => (
        <FloatingParticle key={index} position={position as [number, number, number]} />
      ))}
    </>
  )
}

const Hero = () => {
  return (
    <section id="hero" className="min-h-screen flex flex-col justify-center pt-16 px-4 sm:px-6 lg:px-8">
      <div className="container mx-auto flex flex-col lg:flex-row items-center">
        <motion.div 
          className="lg:w-1/2 mb-8 lg:mb-0 text-center lg:text-left"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4 text-gray-800 dark:text-white">
            Secure Verification & Messaging Solutions
          </h1>
          <p className="text-lg sm:text-xl mb-6 text-gray-600 dark:text-gray-300">
            OTP2Link provides powerful SMS, email verification, bulk SMS, and WhatsApp messaging services for your business needs.
          </p>
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-block"
          >
            <Button size="lg" className="bg-black text-white hover:bg-gray-800">Get Started</Button>
          </motion.div>
        </motion.div>
        <motion.div 
          className="lg:w-1/2 h-[300px] sm:h-[400px] lg:h-[500px] w-full"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <Canvas>
            <PerspectiveCamera makeDefault position={[0, 0, 10]} />
            <OrbitControls 
              enableZoom={false} 
              enablePan={false}
              enableRotate={false}
            />
            <ambientLight intensity={0.5} />
            <spotLight 
              position={[10, 10, 10]} 
              angle={0.15} 
              penumbra={1}
              intensity={0.8}
            />
            <pointLight position={[-10, -10, -10]} intensity={0.5} />
            <Suspense fallback={null}>
              <Scene />
            </Suspense>
          </Canvas>
        </motion.div>
      </div>
    </section>
  )
}

export default Hero

