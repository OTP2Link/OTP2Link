"use client"

import { motion } from 'framer-motion'
import { Check } from 'lucide-react'
import { Button } from "@/components/ui/button"

const plans = [
  {
    name: 'Starter',
    price: '$29',
    features: ['1,000 SMS/month', '5,000 Emails/month', 'Basic support', 'API access']
  },
  {
    name: 'Pro',
    price: '$99',
    features: ['10,000 SMS/month', '50,000 Emails/month', 'Priority support', 'Advanced API access', 'WhatsApp integration']
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    features: ['Unlimited SMS', 'Unlimited Emails', 'Dedicated support', 'Custom integrations', 'SLA']
  }
]

const PricingCard = ({ plan, index }) => {
  return (
    <motion.div
      className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ scale: 1.05 }}
    >
      <h3 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">{plan.name}</h3>
      <p className="text-4xl font-bold mb-6 text-primary">{plan.price}</p>
      <ul className="mb-8">
        {plan.features.map((feature, featureIndex) => (
          <motion.li 
            key={featureIndex} 
            className="flex items-center mb-2 text-gray-600 dark:text-gray-300"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: featureIndex * 0.1 }}
          >
            <Check className="h-5 w-5 text-green-500 mr-2" />
            {feature}
          </motion.li>
        ))}
      </ul>
      <motion.div
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Button className="w-full">Choose Plan</Button>
      </motion.div>
    </motion.div>
  )
}

const Pricing = () => {
  return (
    <section id="pricing" className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.h2 
          className="text-3xl font-bold text-center mb-12 text-gray-800 dark:text-white"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Pricing Plans
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <PricingCard key={index} plan={plan} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}

export default Pricing

