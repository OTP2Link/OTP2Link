"use client"

import { motion } from 'framer-motion'
import { MessageSquare, Mail, Send, Phone } from 'lucide-react'

const features = [
  {
    icon: <MessageSquare className="h-8 w-8 text-primary" />,
    title: 'SMS Verification',
    description: 'Secure and reliable SMS-based OTP verification for your applications.'
  },
  {
    icon: <Mail className="h-8 w-8 text-primary" />,
    title: 'Email Verification',
    description: 'Robust email verification system to ensure user authenticity.'
  },
  {
    icon: <Send className="h-8 w-8 text-primary" />,
    title: 'Bulk SMS',
    description: 'Efficiently send bulk SMS messages for marketing or notifications.'
  },
  {
    icon: <Phone className="h-8 w-8 text-primary" />,
    title: 'WhatsApp Messaging',
    description: 'Integrate WhatsApp messaging capabilities into your services.'
  }
]

const FeatureCard = ({ icon, title, description, index }) => {
  return (
    <motion.div
      className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <motion.div 
        className="mb-4"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: index * 0.1 + 0.2 }}
      >
        {icon}
      </motion.div>
      <h3 className="text-xl font-semibold mb-2 text-gray-800 dark:text-white">{title}</h3>
      <p className="text-gray-600 dark:text-gray-300">{description}</p>
    </motion.div>
  )
}

const Features = () => {
  return (
    <section id="features" className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.h2 
          className="text-3xl font-bold text-center mb-12 text-gray-800 dark:text-white"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Our Features
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <FeatureCard key={index} {...feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}

export default Features

